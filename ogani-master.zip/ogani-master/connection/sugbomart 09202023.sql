/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.14-MariaDB : Database - sugbomart
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sugbomart` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sugbomart`;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `TotalPrice` double(10,2) DEFAULT 0.00,
  `UserID` int(11) DEFAULT 0,
  `Status` tinyint(1) DEFAULT 0,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `cart` */

insert  into `cart`(`ID`,`ProductID`,`Quantity`,`Price`,`TotalPrice`,`UserID`,`Status`,`DateAdded`,`DateUpdated`) values 
(4,1,1,20.00,20.00,8,1,'2023-08-30 16:31:45','2023-08-30 17:57:53'),
(8,5,2,12.00,24.00,8,1,'2023-08-30 17:27:42','2023-08-30 17:57:53'),
(11,9,1,56.00,56.00,8,1,'2023-08-30 18:03:56','2023-08-30 18:35:45'),
(6,3,3,15.00,45.00,8,1,'2023-08-30 16:39:21','2023-08-30 17:57:53'),
(10,7,2,35.00,70.00,8,1,'2023-08-30 17:58:53','2023-08-30 17:59:10'),
(12,4,1,56.00,56.00,8,1,'2023-08-30 18:35:08','2023-08-30 18:35:45'),
(13,8,4,35.00,140.00,8,1,'2023-08-30 18:35:28','2023-08-30 18:35:45'),
(14,2,1,20.00,20.00,8,0,'2023-08-30 19:19:32','2023-08-30 19:19:32'),
(15,1,1,20.00,20.00,8,0,'2023-08-30 19:20:48','2023-08-30 19:20:48'),
(16,5,5,12.00,60.00,8,0,'2023-08-30 19:21:25','2023-08-30 19:21:42');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CartID` int(11) DEFAULT NULL,
  `OrderDate` datetime DEFAULT current_timestamp(),
  `ReceiveDate` datetime DEFAULT NULL,
  `OrderStatusID` int(11) DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `order` */

insert  into `order`(`ID`,`CartID`,`OrderDate`,`ReceiveDate`,`OrderStatusID`) values 
(1,4,'2023-08-30 17:57:53',NULL,0),
(2,8,'2023-08-30 17:57:53',NULL,0),
(3,6,'2023-08-30 17:57:53',NULL,0),
(4,10,'2023-08-30 17:59:10',NULL,0),
(5,11,'2023-08-30 18:35:45',NULL,0),
(6,12,'2023-08-30 18:35:45',NULL,0),
(7,13,'2023-08-30 18:35:45',NULL,0);

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(60) DEFAULT NULL,
  `ProductDesc` varchar(255) DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `DiscountedPrice` double(10,2) DEFAULT 0.00,
  `Quantity` int(11) DEFAULT 0,
  `StoreID` int(11) DEFAULT 0,
  `DateAdded` timestamp NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `products` */

insert  into `products`(`ID`,`ProductName`,`ProductDesc`,`Price`,`DiscountedPrice`,`Quantity`,`StoreID`,`DateAdded`,`DateUpdated`) values 
(1,'Product 101','Product 101',20.00,19.00,10,1,'2023-08-30 15:47:37','2023-08-30 15:47:37'),
(2,'Product 202','Product 202',20.00,18.00,10,1,'2023-08-30 15:47:50','2023-08-30 15:47:50'),
(3,'Product 303','Product 303',15.00,14.00,15,1,'2023-08-30 15:55:07','2023-08-30 15:55:07'),
(4,'Product 404','Product 404',56.00,25.00,25,1,'2023-08-30 15:55:12','2023-08-30 15:55:22'),
(5,'Product 505','Product 505',12.00,23.00,22,1,'2023-08-30 15:55:30','2023-08-30 15:55:38'),
(6,'Product 606','Product 606',12.00,25.00,55,2,'2023-08-30 15:55:51','2023-08-30 15:55:51'),
(7,'Product 707','Product 707',35.00,32.00,255,2,'2023-08-30 15:56:07','2023-08-30 15:56:20'),
(8,'Product 808','Product 808',35.00,23.00,223,2,'2023-08-30 15:56:25','2023-08-30 15:56:38'),
(9,'Product 909','Product 909',56.00,26.00,333,2,'2023-08-30 15:56:53','2023-08-30 15:56:56');

/*Table structure for table `store` */

DROP TABLE IF EXISTS `store`;

CREATE TABLE `store` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StoreName` varchar(255) DEFAULT NULL,
  `StoreAddress` longtext DEFAULT NULL,
  `UserID` int(11) DEFAULT 0,
  `DateAdded` timestamp NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `store` */

insert  into `store`(`ID`,`StoreName`,`StoreAddress`,`UserID`,`DateAdded`,`DateUpdated`) values 
(1,'Store 101','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(2,'Store 202','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(3,'Store 303','Cebu City',10,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(4,'Store 404','Cebu City',10,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(5,'Store 505','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(6,'Store 606','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(7,'Store 707','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(8,'Store 808','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ShopName` varchar(50) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `BusinessPermit` varchar(40) DEFAULT NULL,
  `PhoneNumber` varchar(25) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Status` tinyint(1) DEFAULT 0,
  `UserType` varchar(20) DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`ID`,`FirstName`,`LastName`,`ShopName`,`Address`,`BusinessPermit`,`PhoneNumber`,`Email`,`Password`,`Status`,`UserType`,`date_added`,`date_updated`) values 
(8,'User 1','User 1','User','Address','#1','12312311','angelo.roccatech@gmail.com','76d80224611fc919a5d54f0ff9fba446',0,'1','2023-08-29 19:04:11','2023-08-30 15:26:44'),
(9,'Angelo','Fernandez','AMF Store',NULL,'03891283123','09956143191','angelo.roccatech@gmail.com','e10adc3949ba59abbe56e057f20f883e',0,'2','2023-08-30 15:27:22','2023-08-30 15:27:22'),
(10,'Gelo','Fernandez','AMF Store v2',NULL,'31232512333','09204570423','angelo.toyntoys@gmail.com','e10adc3949ba59abbe56e057f20f883e',0,'2','2023-08-30 15:28:00','2023-08-30 15:28:00');

/*Table structure for table `wishlist` */

DROP TABLE IF EXISTS `wishlist`;

CREATE TABLE `wishlist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `TotalPrice` double(10,2) DEFAULT 0.00,
  `UserID` int(11) DEFAULT 0,
  `Status` tinyint(1) DEFAULT 0,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `wishlist` */

insert  into `wishlist`(`ID`,`ProductID`,`Quantity`,`Price`,`TotalPrice`,`UserID`,`Status`,`DateAdded`,`DateUpdated`) values 
(6,2,1,20.00,20.00,8,0,'2023-08-30 16:39:13','2023-08-30 16:39:13'),
(7,1,1,20.00,20.00,8,0,'2023-08-30 19:20:03','2023-08-30 19:20:03');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
