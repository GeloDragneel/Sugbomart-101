/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.14-MariaDB : Database - sugbomart
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sugbomart` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sugbomart`;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `TotalPrice` double(10,2) DEFAULT 0.00,
  `UserID` int(11) DEFAULT 0,
  `Status` tinyint(1) DEFAULT 0,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

/*Data for the table `cart` */

insert  into `cart`(`ID`,`ProductID`,`Quantity`,`Price`,`TotalPrice`,`UserID`,`Status`,`DateAdded`,`DateUpdated`) values 
(4,1,1,20.00,20.00,8,1,'2023-08-30 16:31:45','2023-08-30 17:57:53'),
(8,5,2,12.00,24.00,8,1,'2023-08-30 17:27:42','2023-08-30 17:57:53'),
(11,9,1,56.00,56.00,8,1,'2023-08-30 18:03:56','2023-08-30 18:35:45'),
(6,3,3,15.00,45.00,8,1,'2023-08-30 16:39:21','2023-08-30 17:57:53'),
(10,7,2,35.00,70.00,8,1,'2023-08-30 17:58:53','2023-08-30 17:59:10'),
(12,4,1,56.00,56.00,8,1,'2023-08-30 18:35:08','2023-08-30 18:35:45'),
(13,8,4,35.00,140.00,8,1,'2023-08-30 18:35:28','2023-08-30 18:35:45'),
(18,5,2,12.00,24.00,8,1,'2023-09-07 19:10:25','2023-09-07 19:14:45'),
(15,1,2,20.00,40.00,8,1,'2023-08-30 19:20:48','2023-09-07 19:14:45'),
(17,2,2,20.00,40.00,8,1,'2023-09-07 19:10:03','2023-09-07 19:14:45'),
(28,1,7,19.00,133.00,8,1,'2023-09-20 12:05:10','2023-09-20 12:05:19');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) DEFAULT NULL,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `category` */

insert  into `category`(`ID`,`CategoryName`,`DateAdded`,`DateUpdated`) values 
(1,'Fresh Meat','2023-09-20 12:19:33','2023-09-20 12:19:33'),
(2,'Vegetables','2023-09-20 12:19:40','2023-09-20 12:19:40'),
(3,'Fruit & Nut Gifts','2023-09-20 12:19:47','2023-09-20 12:19:47'),
(4,'Fresh Berries','2023-09-20 12:19:53','2023-09-20 12:19:53'),
(5,'Ocean Foods','2023-09-20 12:19:58','2023-09-20 12:19:58'),
(6,'Butter & Eggs','2023-09-20 12:19:58','2023-09-20 12:19:58'),
(7,'Fastfood','2023-09-20 12:20:06','2023-09-20 12:20:06'),
(8,'Fresh Onion','2023-09-20 12:20:11','2023-09-20 12:20:11'),
(9,'Papayaya & Crisps','2023-09-20 12:20:14','2023-09-20 12:20:14'),
(10,'Oatmeal','2023-09-20 12:20:19','2023-09-20 12:20:19'),
(11,'Fresh Bananas','2023-09-20 12:20:19','2023-09-20 12:20:19');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CartID` int(11) DEFAULT NULL,
  `OrderDate` datetime DEFAULT current_timestamp(),
  `ReceiveDate` datetime DEFAULT NULL,
  `OrderStatusID` int(11) DEFAULT 0,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `order` */

insert  into `order`(`ID`,`CartID`,`OrderDate`,`ReceiveDate`,`OrderStatusID`) values 
(1,4,'2023-08-30 17:57:53',NULL,0),
(2,8,'2023-08-30 17:57:53',NULL,0),
(3,6,'2023-08-30 17:57:53',NULL,0),
(4,10,'2023-08-30 17:59:10',NULL,0),
(5,11,'2023-08-30 18:35:45',NULL,0),
(6,12,'2023-08-30 18:35:45',NULL,0),
(7,13,'2023-08-30 18:35:45',NULL,0),
(8,18,'2023-09-07 19:14:45',NULL,0),
(9,15,'2023-09-07 19:14:45',NULL,0),
(10,17,'2023-09-07 19:14:45',NULL,0),
(11,28,'2023-09-20 12:05:19',NULL,0);

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(60) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT 0,
  `ProductDesc` longtext DEFAULT NULL,
  `ProductInfo` longtext DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `DiscountedPrice` double(10,2) DEFAULT 0.00,
  `Unit` varchar(10) DEFAULT NULL,
  `Quantity` int(11) DEFAULT 0,
  `StoreID` int(11) DEFAULT 0,
  `ExpiryDate` date DEFAULT NULL,
  `DateAdded` timestamp NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `products` */

insert  into `products`(`ID`,`ProductName`,`CategoryID`,`ProductDesc`,`ProductInfo`,`Price`,`DiscountedPrice`,`Unit`,`Quantity`,`StoreID`,`ExpiryDate`,`DateAdded`,`DateUpdated`) values 
(1,'Product 101',7,'Despite his tragically short time in the spotlight, Bruce Lee was able to cast a huge shadow that spanned the globe, encompassing not just martial arts, but Hollywood, pop culture, and the imagination of millions of fans! This 7” scale, highly articulated ULTIMATES! figure of “The Warrior” features Bruce Lee in his kung fu outfit and comes with interchangeable alternate heads & hands and a variety of other accessories, including real\nmetal chain nunchucks, a bo staff, and removable soft goods undershirt & jacket. Don’t miss the connection, get your made-to-order Bruce Lee ULTIMATES! Figures while you can because your chance to get one, much like a punch from Bruce Lee, will pass in the blink of an eye!','TEST',20.00,19.00,'KG',10,1,'2023-09-23','2023-08-30 15:47:37','2023-09-20 12:31:02'),
(2,'Product 202',0,'Product 202',NULL,20.00,18.00,'PCS',10,1,'2023-09-23','2023-08-30 15:47:50','2023-09-20 11:52:16'),
(3,'Product 303',0,'Product 303',NULL,15.00,14.00,'KG',15,1,'2023-09-24','2023-08-30 15:55:07','2023-09-20 11:52:20'),
(4,'Product 404',0,'Product 404',NULL,56.00,25.00,'KG',25,1,'2023-09-25','2023-08-30 15:55:12','2023-09-20 11:52:24'),
(5,'Product 505',0,'Product 505 Description',NULL,12.00,23.00,'PCS',22,1,'2023-09-26','2023-08-30 15:55:30','2023-09-20 11:52:27'),
(6,'Product 606',0,'Product 606',NULL,12.00,25.00,'PCS',55,2,'2023-09-27','2023-08-30 15:55:51','2023-09-20 11:52:31'),
(7,'Product 707',0,'Product 707',NULL,35.00,32.00,'PCS',255,2,'2023-09-28','2023-08-30 15:56:07','2023-09-20 11:52:06'),
(8,'Product 808',0,'Product 808',NULL,35.00,23.00,'PCS',223,2,'2023-09-28','2023-08-30 15:56:25','2023-09-20 11:52:09'),
(9,'Product 909 v2 1',11,'Product 909','',56.00,26.00,'PCS',333,2,'2023-09-29','2023-08-30 15:56:53','2023-09-20 12:25:21');

/*Table structure for table `store` */

DROP TABLE IF EXISTS `store`;

CREATE TABLE `store` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `StoreName` varchar(255) DEFAULT NULL,
  `StoreAddress` longtext DEFAULT NULL,
  `UserID` int(11) DEFAULT 0,
  `DateAdded` timestamp NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `store` */

insert  into `store`(`ID`,`StoreName`,`StoreAddress`,`UserID`,`DateAdded`,`DateUpdated`) values 
(1,'Store 101','SM Cebu',9,'2023-08-30 15:45:43','2023-09-19 11:51:43'),
(2,'Store 202','SM City (Seaside)',9,'2023-08-30 15:45:43','2023-09-19 11:51:34'),
(3,'Store 303','Cebu City',10,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(4,'Store 404','Cebu City',10,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(5,'Store 505','V Rama Street',9,'2023-08-30 15:45:43','2023-09-19 11:51:16'),
(6,'Store 606','Colon Cebu City',9,'2023-08-30 15:45:43','2023-09-19 11:51:03'),
(7,'Store 707','Talisay City',9,'2023-08-30 15:45:43','2023-09-19 11:50:53'),
(8,'Store 808','Cebu City',9,'2023-08-30 15:45:43','2023-08-30 15:45:43'),
(9,'Store 909','Mandaue City',9,'2023-09-19 11:50:16','2023-09-19 11:50:46');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ShopName` varchar(50) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Address2` varchar(255) DEFAULT NULL,
  `BusinessPermit` varchar(40) DEFAULT NULL,
  `PhoneNumber` varchar(25) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Status` tinyint(1) DEFAULT 0,
  `UserType` varchar(20) DEFAULT NULL COMMENT '0 = Admin; 1 = Shopper; 2 = Vendor',
  `OTP` varchar(10) DEFAULT '0',
  `IsValidate` tinyint(1) DEFAULT 0,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`ID`,`FirstName`,`LastName`,`ShopName`,`Address`,`Address2`,`BusinessPermit`,`PhoneNumber`,`Email`,`Password`,`Status`,`UserType`,`OTP`,`IsValidate`,`date_added`,`date_updated`) values 
(8,'Michael','Jackson','User','18A J. M. Basa Street Cebu City','TEST','#1','12312311','angelo.roccatech@gmail.com','e10adc3949ba59abbe56e057f20f883e',1,'1','0',1,'2023-08-29 19:04:11','2023-11-23 18:37:41'),
(9,'Angelo','Fernandez','AMF Store','',NULL,'03891283123','09956143191','angelo.roccatech2@gmail.com','e10adc3949ba59abbe56e057f20f883e',1,'2','0',1,'2023-08-30 15:27:22','2023-11-23 18:11:56'),
(10,'Gelo','Fernandez','AMF Store v2','',NULL,'31232512333','09204570423','angelo.toyntoys@gmail.com','e10adc3949ba59abbe56e057f20f883e',1,'2','0',1,'2023-08-30 15:28:00','2023-11-23 18:11:56'),
(11,'John','Doe',NULL,'',NULL,'112312','098123','admin@gmail.com','e10adc3949ba59abbe56e057f20f883e',1,'0','0',1,'2023-09-18 18:47:07','2023-11-23 18:11:55'),
(12,'HiGelo','Fernandez','Yow',NULL,NULL,'132233','1512333','angelo.toyntoys@gmail.com','e10adc3949ba59abbe56e057f20f883e',0,'1','0',1,'2023-11-23 16:45:28','2023-11-23 18:11:55'),
(14,'123','123','',NULL,NULL,'','123','la.gelo.fernandez@gmail.com','e10adc3949ba59abbe56e057f20f883e',0,'1','826072',1,'2023-11-23 17:46:15','2023-11-23 18:26:35');

/*Table structure for table `wishlist` */

DROP TABLE IF EXISTS `wishlist`;

CREATE TABLE `wishlist` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` double(10,2) DEFAULT 0.00,
  `TotalPrice` double(10,2) DEFAULT 0.00,
  `UserID` int(11) DEFAULT 0,
  `Status` tinyint(1) DEFAULT 0,
  `DateAdded` timestamp NOT NULL DEFAULT current_timestamp(),
  `DateUpdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `wishlist` */

insert  into `wishlist`(`ID`,`ProductID`,`Quantity`,`Price`,`TotalPrice`,`UserID`,`Status`,`DateAdded`,`DateUpdated`) values 
(6,2,1,20.00,20.00,8,0,'2023-08-30 16:39:13','2023-08-30 16:39:13'),
(8,1,1,20.00,20.00,8,0,'2023-09-07 19:09:43','2023-09-07 19:09:43');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
